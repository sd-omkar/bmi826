#' Cube function
#' 
#' Returns the cube of input provided
#' @param x input number
#' @return Cube of input x
#' @export
cube <- function(x) {
  return(x^3)
}

